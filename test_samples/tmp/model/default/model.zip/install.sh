#!/bin/bash

echo "FROM install.sh node default"

sleep 5