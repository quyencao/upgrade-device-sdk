#!/bin/bash

echo "FROM install.sh node 1"

sleep 5