#!/bin/bash

echo "FROM install.sh node 2"

sleep 5