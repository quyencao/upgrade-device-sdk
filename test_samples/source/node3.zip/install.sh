#!/bin/bash

echo "FROM install.sh node 3"

sleep 5